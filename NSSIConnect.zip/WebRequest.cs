using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using System.Configuration;
using System.Net;
using Experian.BureauTools.Shared;

namespace NSSIConnect
{
	/// <summary>
	/// Summary description for WebRequest.
	/// </summary>
	public class WebRequest
	{
		public WebRequest()
		{
			Uri uri = new Uri("https://applications.noi.bg/client-test");
			HttpWebRequest request = null;
			HttpWebResponse response = null;
			
			try
			{
				request = (HttpWebRequest)System.Net.WebRequest.Create(uri);
				request.ClientCertificates.Add(WinCapi.Certificate);
				response = (HttpWebResponse)request.GetResponse();	
			}
			catch(Exception e)
			{
				EventViewer.WriteError(e.Message);
			}
			finally
			{
				response.Close();
			}

		}
	}
}
