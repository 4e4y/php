using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using System.Configuration;
using System.Net;

using Experian.BureauTools.Shared;
using Experian.BureauTools.Shared.UnmanagedWrappers;

namespace NSSIConnect
{
	/// <summary>
	/// Main Class for NssiConnect Application
	/// </summary>
	class NSSIConnectClient
	{
		#region Enums

		private enum ReturnStatus : short
		{
			NO_DATA = 0,
			SUCCESS = 1,
			NSSI_ERROR = 2,
			TRANSPORT_ERROR = 3,
			INTERNAL_ERROR = 4
		}

		private enum EnquiryType : short
		{
			Consumer = 1,
			Business
		}

		#endregion Enums

		#region Main

		/// <summary>
		/// Entry point for NssiConnect Application
		/// </summary>
		/// <param name="args">Input parameters - expects 2 filenames</param>
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				if (args.Length != 2)
				{
					throw new Exception("ExternalCalls::NssiConnect invalid arguments");
				}
				NSSIConnectClient client = new NSSIConnectClient(args);
				client.Run();
			}
			catch (Exception ex)
			{
				EventViewer.WriteError("NssiConnect: " + ex.Message);
			}
		}

		#endregion Main

		#region Members

		private ManagedMetaObject request;
		private ManagedMetaObject response;
		private string requestPath = "";
		private string responsePath = "";

		/// Used for acquiring certificate
		private WinCapi _objWinCapi = null;
		// private WinCapi _objWinCapi = WinCapi.Instance;
		private X509Certificate _objCertificate = null;

		/// The web service proxy
		private Service12 serviceProxy;

		/// These hold request values
		short _nRequestType = 0;
		short RepNo = 0;
		string bulstat = "";
		short FromYear = 0;
		short ToYear = 0;
		short FromMonth = 0;
		short ToMonth = 0;

		/// This holds the result data
		DataSet dataSet;

		bool TestFlag = false;

		#endregion Members

		#region Properties

		/// <summary>
		/// Returns Certificate Username
		/// depending on Configuration Build and Machine Name
		/// </summary>
		private string Username
		{
			get
			{

				#region MONACO
#if MONACO
#if DEMO
				return "exscomonaco2007";
#else
				return "Monaco2009";
#endif
#endif
				#endregion

				#region BULGARIA
#if BULGARIA
				// return "ExScoSofia2009";
				// return "ExScoSofia2010";
#if IIIDC
				return "CBV1Gate2011";
#endif
				return "ExScoSofia2011";
#endif
				#endregion

				#region NOTHINGHAM
#if NOTH
				string strMachineName = System.Environment.MachineName;
				if (strMachineName.Trim().EndsWith("DBC01"))
				{
					// return "Ukdbc012009";
					return "Ukdbc012010";
				}
				if (strMachineName.Trim().EndsWith("DBC02"))
				{
					// return "Ukdbc022009";
					return "Ukdbc022010";
				}
#endif
				#endregion NOTHINGHAM

				return string.Empty;
			}
		}

		#endregion Properties

		#region Constructors

		public NSSIConnectClient(string[] args)
		{
			requestPath = args[0];
			responsePath = args[1];
			request = ManagedCallHelper.ReadFile(requestPath);
			try
			{
				response = ManagedMetaObject.Create();
			}
			catch (Exception e)
			{
				e = e;
			}

			/// Check if there are Subscribers configured for Test Call
			if (ConfigurationSettings.AppSettings["testSubscribers"] != null)
			{
				string SID = "";			
				string AppTestSubscribersStr = "";
				request.GetValue("[0].SID", ref SID);
				AppTestSubscribersStr = ConfigurationSettings.AppSettings["testSubscribers"];
				string CurrTestSubscriber = "";
				int TestSubscribersCnt = 0;
				TestSubscribersCnt = AppTestSubscribersStr.Split(',').Length;
				for(int i=0; i<TestSubscribersCnt; i++)
				{
					CurrTestSubscriber = AppTestSubscribersStr.Split(',')[i].Trim();
					if(CurrTestSubscriber == SID)
					{
						TestFlag = true;
						break;
					}
				}
			}
		}

		#endregion Constructors
        
		#region Public Methods

		public void Run()
		{
			try
			{
				if(!TestFlag)
				{
					processRequest();
					ManagedCallHelper.WriteFile(responsePath, response);
				}
				else
				{
					request.GetValue("[0].requestType", ref _nRequestType);
					if (_nRequestType > 0)
					{
						string strExternalCallsDir = string.Empty;
						ManagedConfiguration.MustFindValue("ExternalCalls/RequestFolder", ref strExternalCallsDir);
						DirectoryInfo objDirectoryInfo = new DirectoryInfo(strExternalCallsDir);

						using(StreamWriter objStreamWriter = new StreamWriter(responsePath))
						{
							/// Put beginning of the Xml
							objStreamWriter.WriteLine(string.Format("<s>{0}",
								Environment.NewLine));

							int nReportIndex = 0;
							for (;nReportIndex < request.Length; nReportIndex++)
							{
								string strReportNumber = string.Empty;
								request.GetValue(string.Format("[{0}].RepNo", nReportIndex), ref strReportNumber);

								string strEGN = string.Empty;
								if (strReportNumber == "GRAO")
								{
									string strOutputXml = string.Format(@"{0}\GRAO.xml",
										objDirectoryInfo.Parent.FullName);
									strEGN = string.Empty;
									request.GetValue(string.Format("[{0}].EGN", nReportIndex), ref strEGN);
									if (File.Exists(string.Format(@"{0}\GRAO_{1}.xml",
										objDirectoryInfo.Parent.FullName,
										strEGN.Substring(0, 10))))
									{
										strOutputXml = string.Format(@"{0}\GRAO_{1}.xml",
											objDirectoryInfo.Parent.FullName,
											strEGN.Substring(0, 10));
									}

									using (StreamReader objStreamReader = new StreamReader(strOutputXml))
									{
										objStreamWriter.Write(objStreamReader.ReadToEnd());
										objStreamWriter.Flush();

										objStreamReader.Close();
									}
								}
								else
								{
									string strOutputXmlReport = string.Format(@"{0}\TestReport{1}.xml",
										objDirectoryInfo.Parent.FullName,
										strReportNumber);

									if (strReportNumber == "160")
									{
										strEGN = string.Empty;
										request.GetValue(string.Format("[{0}].Bulstat", nReportIndex), ref strEGN);
										if (File.Exists(string.Format(@"{0}\TestReport{1}_{2}.xml",
											objDirectoryInfo.Parent.FullName,
											strReportNumber,
											strEGN)))
										{
											strOutputXmlReport = string.Format(@"{0}\TestReport{1}_{2}.xml",
												objDirectoryInfo.Parent.FullName,
												strReportNumber,
												strEGN);
										}
									}
									else
									{
										strEGN = string.Empty;
										request.GetValue(string.Format("[{0}].EGN", nReportIndex), ref strEGN);
										if (File.Exists(string.Format(@"{0}\TestReport{1}_{2}.xml",
											objDirectoryInfo.Parent.FullName,
											strReportNumber,
											strEGN.Substring(0, 10))))
										{
											strOutputXmlReport = string.Format(@"{0}\TestReport{1}_{2}.xml",
												objDirectoryInfo.Parent.FullName,
												strReportNumber,
												strEGN.Substring(0, 10));
										}
									}
									
									if (File.Exists(strOutputXmlReport))
									{
										using (StreamReader objStreamReader = new StreamReader(strOutputXmlReport))
										{
											objStreamWriter.Write(objStreamReader.ReadToEnd());
											objStreamWriter.Flush();

											objStreamReader.Close();
										}
									}
									else
									{
										objStreamWriter.WriteLine(string.Format("<s n=\"report{0}\">{1}",
											strReportNumber,
											Environment.NewLine));
										objStreamWriter.WriteLine(string.Format("<a n=\"status\">{0}</a>{1}",
											(int)ReturnStatus.INTERNAL_ERROR,
											Environment.NewLine));
										objStreamWriter.WriteLine(string.Format("</s>{0}",
											Environment.NewLine));
									}
								}
							}

							/// Put end of the Xml
							objStreamWriter.WriteLine(string.Format("</s>{0}",
								Environment.NewLine));
						}
					}
				}
			}
			catch(Exception ex)
			{
				EventViewer.WriteError("NssiConnect: WriteFile " + ex.Message);
			}
			
			try
			{
				if (_objWinCapi != null)
				{
					_objWinCapi.freeRessources();
				}
			}
			catch(Exception ex)
			{
				EventViewer.WriteError("NssiConnect: Free Ressources " + ex.Message);
			}
		}
        
		#endregion Public Methods

		#region Private Methods

		private bool ConstructService()
		{				
			string NSSI_UseProxy = ConfigurationSettings.AppSettings["NSSI_UseProxy"];
			if (NSSI_UseProxy == null ||
				NSSI_UseProxy.Trim() == string.Empty)
			{
				return false;
			}

#if DEBUG
			EventViewer.WriteInformation("useProxy: " + NSSI_UseProxy);
#endif

			if (NSSI_UseProxy.Trim() != "1")
			{
				return false;
			}

			string proxyAddress = string.Empty;
			string proxyPort = string.Empty;

			//To Do: Add Passwords
			string proxyUser = string.Empty;
			string proxyPassword = string.Empty;
			
			///Get NSSI Proxy Address and Port Number from the config file
			proxyAddress = ConfigurationSettings.AppSettings["NSSI_ProxyAddress"];
			if (proxyAddress == null ||
				proxyAddress.Trim() == string.Empty)
			{
				return false;
			}
#if DEBUG
			EventViewer.WriteInformation("proxyAddress: " + proxyAddress);
#endif
			proxyPort = ConfigurationSettings.AppSettings["NSSI_ProxyPort"];
			if (proxyPort == null ||
				proxyPort.Trim() == string.Empty)
			{
				return false;
			}
#if DEBUG
			EventViewer.WriteInformation("proxyPort: " + proxyPort);
#endif
		

			proxyUser = ConfigurationSettings.AppSettings["NSSI_ProxyUser"];
			if (proxyUser == null ||
				proxyUser.Trim() == string.Empty)
			{
				return false;
			}

			proxyPassword = ConfigurationSettings.AppSettings["NSSI_ProxyPass"];
			if (proxyPassword == null ||
				proxyPassword.Trim() == string.Empty)
			{
				return false;
			}

			///Validate IPAddress and Port Number
			int nProxyPort;
			
			try
			{
				nProxyPort = int.Parse(proxyPort);
			}
			catch (Exception e)
			{
#if DEBUG
				EventViewer.WriteInformation("Invalid Port Number: " + e);
#else
				EventViewer.WriteInformation("Invalid Port Number: " + e.Message);
#endif
				return false;
			}

			if (nProxyPort < 1 || nProxyPort > 65535)
			{
#if DEBUG
				EventViewer.WriteInformation("Invalid Port Number");
#else
				EventViewer.WriteInformation("Invalid Port Number");
#endif
				return false;
			}
			
			try
			{
				IPAddress proxyIPAddress = IPAddress.Parse(proxyAddress);

				///Set Proxy to serciceProxy object	
				NetworkCredential credentials = new NetworkCredential(proxyUser, proxyPassword);
				WebProxy proxy = new WebProxy(proxyAddress, nProxyPort);
				proxy.Credentials = credentials;
				
				
				serviceProxy.Proxy = proxy;
				
				
			
				return true;
			}
			catch(Exception ex)
			{
#if DEBUG
				EventViewer.WriteInformation("Invalid IP: " + ex);
#else
				EventViewer.WriteInformation("Invalid IP: " + ex.Message);
#endif
			}

			return false;
		}

		private void processRequest()
		{
			int nReportIndex = 0;

			request.GetValue(string.Format("[{0}].requestType", nReportIndex), ref _nRequestType);

			if (_nRequestType == 0)
			{
				setOutcome(0,ReturnStatus.NO_DATA);
				return;
			}

#if NOREQUEST
			setOutcome(_nRequestType, ReturnStatus.SUCCESS);
			return;;
#endif

			XmlNode resp = new XmlDocument();
			for (;nReportIndex < request.Length; nReportIndex++)
			{
				string strReportNumber = string.Empty;
				request.GetValue(string.Format("[{0}].RepNo", nReportIndex), ref strReportNumber);

				string strEGN = string.Empty;
				if (strReportNumber == "GRAO")
				{
					/// TODO: Add Fake Request Implementation
					///GRAO.ExperianScorex objGRRAO = new GRAO.ExperianScorex();
					GRAO.ExperianScorexTest objGRRAO = new GRAO.ExperianScorexTest();
					request.GetValue(string.Format("[{0}].EGN", nReportIndex), ref strEGN);
					if (strEGN.Length > 10)
					{
						strEGN = strEGN.Substring(0, 10);
					}

					StringBuilder objStringBuilder = new StringBuilder();

					try
					{
						GRAO.GraoResponse objGRAOResponse = objGRRAO.GetPersonData(strEGN);
						objGRRAO.Timeout = 15000;
						StringWriter objWriter = new StringWriter(objStringBuilder);
						XmlSerializer objSerializer = new XmlSerializer(typeof(GRAO.GraoResponse));
						objSerializer.Serialize(objWriter, objGRAOResponse);
					}
					catch (Exception e)
					{
						EventViewer.WriteError("NssiConnect: processRequest(GRAO) " + e.Message);
						setOutcome(strReportNumber,ReturnStatus.TRANSPORT_ERROR);

						continue;
					}

					XmlDocument objXmlDocument = new XmlDocument();
					objXmlDocument.LoadXml(objStringBuilder.ToString());

					processResponse(objXmlDocument.DocumentElement, strReportNumber);
				}
				else
				{
					RepNo = 0;
					request.GetValue(string.Format("[{0}].RepNo", nReportIndex), ref RepNo);

					if (RepNo > 0)
					{
						if (_objWinCapi == null)
						{
							_objWinCapi = WinCapi.Instance;
							// _objCertificate = _objWinCapi.getCertificate();
							_objCertificate = WinCapi.Certificate;
						
							if (_objCertificate == null) 
							{
								EventViewer.WriteInformation("certificate is null");
								_objWinCapi.freeRessources();
								_objWinCapi = null;

								setOutcome(RepNo,ReturnStatus.INTERNAL_ERROR);
								continue; /// No Certificate - No Deal
							}

							EventViewer.WriteInformation(_objCertificate.GetSerialNumberString());
							
							serviceProxy = new Service12(_objCertificate);
							////TO DO: Add proxy things here
							
							ConstructService();

						}

						/// TODO: Add Fake Request Implementation
						request.GetValue(string.Format("[{0}].Bulstat", nReportIndex), ref bulstat);
						request.GetValue(string.Format("[{0}].FromYear", nReportIndex), ref FromYear);
						request.GetValue(string.Format("[{0}].ToYear", nReportIndex), ref ToYear);
						request.GetValue(string.Format("[{0}].FromMonth", nReportIndex), ref FromMonth);
						request.GetValue(string.Format("[{0}].ToMonth", nReportIndex), ref ToMonth);
						request.GetValue(string.Format("[{0}].EGN", nReportIndex), ref strEGN);

						/// This is temporary solution for NOI bug with MAX duration period
						/// If duration period is more than 10 months then we set period to 10 months
						// DateTime dtTempFrom = new DateTime(FromYear, FromMonth, 1);

						//////////////////////////////////////////////////////////////////
						// if (ToYear == 2011)
						// {
						// ToYear = 2010;
						// ToMonth = 12;
						// }
						//////////////////////////////////////////////////////////////////
						DateTime dtTempTo = new DateTime(ToYear, ToMonth, 1);
						DateTime dtTempFrom = dtTempTo.Subtract(TimeSpan.FromDays(334));

						try
						{
#if IIIDC
							EventViewer.WriteInformation("serviceProxy.GetData");
							resp = serviceProxy.GetData(Username, RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, strEGN);
#else
							// resp = serviceProxy.GetData(_strCertUsername, RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, strEGN);
							resp = serviceProxy.GetData(Username, RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, strEGN);
#endif
							
						}
						catch (Exception ex)
						{
							EventViewer.WriteError(string.Format("ProcessRequest R{0}: {1}", RepNo, ex.Message));
							setOutcome(RepNo,ReturnStatus.TRANSPORT_ERROR);
#if DEBUG
							EventViewer.WriteInformation("NSSIConnect:processRequest:setOutcome - " + ReturnStatus.TRANSPORT_ERROR.ToString());
#endif
						}

						try
						{
							if (resp == null)
							{
								EventViewer.WriteError(string.Format("ProcessRequest R{0}: Empty Response", RepNo));
								setOutcome(RepNo,ReturnStatus.NSSI_ERROR);
#if DEBUG
								EventViewer.WriteInformation("NSSIConnect:processRequest:setOutcome - " + ReturnStatus.NSSI_ERROR.ToString());
#endif
								continue;
							}
							else
							{
								if (resp.HasChildNodes)
								{
									int nRequestCounts = 0;
									while (resp.HasChildNodes &&
										resp.FirstChild.Name == "NODATA")
									{
										if (nRequestCounts > 1)
										{
											break;
										}

										try
										{
											// resp = serviceProxy.GetData(_strCertUsername, RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, strEGN);
											resp = serviceProxy.GetData(Username, RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, strEGN);
										}
										catch (Exception) {}

										nRequestCounts++;
									}
								}
							}
						}
						catch (Exception exx)
						{
							EventViewer.WriteError("NssiConnect: processRequest: before processResponse: " + exx.ToString());
						}
						
						processResponse(resp,RepNo);
						
						/*
						if (RepNo == 7 || RepNo == 2)
						{
							setOutcome(RepNo, ReturnStatus.NO_DATA);
						}
						*/
					}
				}
			}
		}

		#region Process Response methods

		private void processResponse(XmlNode node, short repType)
		{
#if DEBUG
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(node.OuterXml);
			doc.Save(string.Format(@"d:\Atlas\Debug\debug_rep{0}_{1}.xml", repType, DateTime.Now.Ticks));
#endif
						
			if(!node.HasChildNodes)
			{

				setOutcome(repType,ReturnStatus.NO_DATA);
				return;
			} 
			else if (node.FirstChild.Name == "NODATA")
			{
				EventViewer.WriteError("NssiConnect: Nssi error "  + node.FirstChild.InnerText);
				setOutcome(repType,ReturnStatus.NSSI_ERROR);
				return;
			}
			else 
			{
				/// Set Success Here, if Anything Goes Wrong Status Will be Overriden
				setOutcome(repType,ReturnStatus.SUCCESS);
			}

			try
			{
				dataSet = new DataSet();
				XmlNodeReader xReader = new XmlNodeReader(node);
				dataSet.ReadXml(xReader, XmlReadMode.InferSchema);
				string path = "report" + repType + ".";
				int index = 0;
				string tbl = "";
				string rusoPath = "Ruso";
				bool rusoChanged = false;
				foreach (DataTable table in dataSet.Tables)
				{
					tbl = table.TableName;
					if(tbl == "PersonalInfo")
					{
						string currRuso = "";
						string currBulstat = "";
						int RusoIndex = 0;
						int BulstatIndex = 0;
						/// First get the Rows Ordered by Ruso
						DataRow[] rusoArray = table.Select("","Ruso,Bulstat ASC");
						if(rusoArray.Length > 0)
						{
							currRuso = (string) rusoArray[0]["Ruso"];
							currBulstat = (string) rusoArray[0]["Bulstat"];
							response.SetValue(path + rusoPath +".[" + RusoIndex + "]." + "RusoNbr",currRuso);
							insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "]." + "Bulstat" + ".[" + BulstatIndex + "].", currBulstat, currRuso);
						}
						/// For Each Row Check if Underneath 
						for(int l = 0; l < rusoArray.Length; l++)
						{
							DataRow currRow = rusoArray[l];
							/// Next Section
							if((string) currRow["Ruso"] != currRuso)
							{
								currRuso = (string) currRow["Ruso"];
								RusoIndex++;
								index = 0;
								rusoChanged = true;
								BulstatIndex = 0;
								response.SetValue(path + rusoPath +".[" + RusoIndex + "]." + "RusoNbr",currRuso);
								insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "].", currBulstat, currRuso);
							}
							if((string) currRow["Bulstat"] != currBulstat)
							{
								currBulstat = (string) currRow["Bulstat"];
								if(!rusoChanged) {BulstatIndex++;}
								insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "].", currBulstat, currRuso);
								index = 0;
								rusoChanged = false;
							}
							for (int k = 0; k < currRow.ItemArray.Length; k++)
							{
								/// Set Path and Value
								DataColumn currCol = (DataColumn) table.Columns[k];
								if(currCol.ColumnName != "Ruso" && currCol.ColumnName != "Bulstat")
								{
									response.SetValue(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "]." + tbl + ".[" + index +"]."+ currCol.ColumnName,(string) currRow[currCol.ColumnName]);
								}
							}
							index++;
						}
					}
					else if (tbl != "BulstatInfo")	
					{
						for (int i = 0; i < table.Rows.Count; i++)
						{
							/// Set Path to Row
							index = i;
							DataRow currRow = table.Rows[i];
							for (int k = 0; k < currRow.ItemArray.Length; k++)
							{
								
								/// Set Path and Value
								DataColumn currCol = (DataColumn) table.Columns[k];
								if(currCol.ColumnName == "EGN")
								{
									/// Remove Last Digit NSSI Puts on EGN
									response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,((string) currRow[currCol.ColumnName]).Substring(0,10));
								}
								else
								{
									if (currRow[currCol.ColumnName] != null &&
										currRow[currCol.ColumnName] != DBNull.Value)
									{
										response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,(currRow[currCol.ColumnName] as string));
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
#if DEBUG
				try
				{
					XmlDocument docEx = new XmlDocument();
					docEx.LoadXml(node.OuterXml);
					docEx.Save(string.Format(@"d:\Atlas\Debug\debug_rep_NSSI{0}_{1}.xml", repType, DateTime.Now.ToString("yyyyMMdd_HHmmss")));
				}
				catch (Exception)	{}
#endif
				EventViewer.WriteError("NssiConnect: Process Response "  + ex.Message);
				setOutcome(repType,ReturnStatus.INTERNAL_ERROR);
			}
		}

		private void processResponse(XmlNode node, string strReportType)
		{
#if DEBUG
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(node.OuterXml);
			doc.Save(string.Format(@"d:\Atlas\Debug\debug_rep{0}_{1}.xml", strReportType, DateTime.Now.Ticks));
#endif

			if(!node.HasChildNodes)
			{
				setOutcome(strReportType,ReturnStatus.NO_DATA);
				return;
			} 
			else if (node.FirstChild.Name == "Status")
			{
				if (node.FirstChild.InnerText.Trim() == "Error" ||
					node.FirstChild.InnerText.Trim() == "EgnError")
				{
					EventViewer.WriteError("NssiConnect: Nssi error "  + node.FirstChild.InnerText);
					setOutcome(strReportType,ReturnStatus.NSSI_ERROR);
					return;
				}
				else if (node.FirstChild.InnerText.Trim() == "NotFound")
				{
					setOutcome(strReportType,ReturnStatus.NO_DATA);
					return;
				}
			}
			else 
			{
				setOutcome(strReportType,ReturnStatus.NSSI_ERROR);
				return;
			}

			/// Set Success Here, if Anything Goes Wrong Status Will be Overriden
			setOutcome(strReportType, ReturnStatus.SUCCESS);

			if (node.ChildNodes[1].Name == "Person")
			{
				string strRootPath = "GRAO.";
				XmlNode objPersonNode = node.ChildNodes[1];
				int nIndex = 0;
				foreach (XmlNode objXmlNode in objPersonNode.ChildNodes)
				{
					try
					{
						if (objXmlNode.HasChildNodes &&
							objXmlNode.FirstChild.NodeType != XmlNodeType.Text)
						{
							if (objXmlNode.Name == "ResidenceAddressHistory" || 
								objXmlNode.Name == "CurrentAddressHistory")
							{
								if (!SetResponseArray(string.Format("{0}{1}.", strRootPath, objXmlNode.Name), objXmlNode, strReportType))
								{
									break;
								}
							}
							else
							{
								if (!SetResponseValue(string.Format("{0}{1}.", strRootPath, objXmlNode.Name), objXmlNode, strReportType))
								{
									break;
								}
							}
						}
						else
						{
							response.SetValue(string.Format("{0}{1}", strRootPath, objXmlNode.Name), objXmlNode.InnerText);
						}
					}
					catch (Exception e)
					{
						EventViewer.WriteError("NssiConnect: processResponse " + e.Message);
						setOutcome(strReportType,ReturnStatus.INTERNAL_ERROR);
						break;
					}

					nIndex++;
				}
			}
			else
			{
				setOutcome(strReportType,ReturnStatus.NO_DATA);
			}
		}


		#endregion Process Response methods

		private void insertBulstatInfo(string thePath, string bulstat, string ruso)
		{
			DataTable bulstatTbl = dataSet.Tables["BulstatInfo"];
			
			EventViewer.WriteInformation(bulstatTbl.Columns.Count.ToString());

			DataRow[] bulstatArray = bulstatTbl.Select("TRIM(Bulstat) =" + bulstat.Trim()  + " and TRIM(Ruso) =" + ruso.Trim());
			if(bulstatArray.Length > 0)
			{
				DataRow currRow = bulstatArray[0];
				for (int k = 0; k < currRow.ItemArray.Length; k++)
				{
					/// Set Path and Value
					DataColumn currCol = (DataColumn) bulstatTbl.Columns[k];
					if(currCol.ColumnName != "Ruso")
					{
						if (currRow[currCol.ColumnName] != null &&
							currRow[currCol.ColumnName] != DBNull.Value)
						{
							response.SetValue(thePath + bulstatTbl.TableName + "."+ currCol.ColumnName,currRow[currCol.ColumnName].ToString());
						}
					}
				}
			}
			else /// Bulstat Number not Found in Bulstat Info Try With EGNInfo
			{
				DataTable egnInfoTbl = dataSet.Tables["EgnInfo"];
				DataRow[] egnArray = egnInfoTbl.Select("EGN LIKE '" + bulstat.Trim() + "*'");
				if(egnArray.Length > 0)
				{
					response.SetValue(thePath + "BulstatInfo.Ruso",ruso);
					DataRow currRow = egnArray[0];
					response.SetValue(thePath + "BulstatInfo.Bulstat",((string) currRow["EGN"]).Substring(0,10));
					response.SetValue(thePath + "BulstatInfo.Name",(string) currRow["familyname"]);
					response.SetValue(thePath + "BulstatInfo.address",(string) currRow["Address"]);
				}
				else ///  Just in Case Put Something There
				{
					response.SetValue(thePath + "BulstatInfo.Ruso",ruso);
					response.SetValue(thePath + "BulstatInfo.Bulstat","");
					response.SetValue(thePath + "BulstatInfo.Name","");
					response.SetValue(thePath + "BulstatInfo.address","");
				}
			}
		}

		#region Set Outcome methods

		private void setOutcome(short RepNo, ReturnStatus status_code)
		{
			string path = "report";
			switch(status_code)
			{
				case ReturnStatus.NO_DATA:
					if(RepNo == 0)
					{
						response.SetValue(path + "2.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "7.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "14.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "122.status", (double)ReturnStatus.NO_DATA);
						response.SetValue("GRAO.status", (double)ReturnStatus.NO_DATA);
					}
					else
					{
						string strCurrentStatus = string.Empty;
						response.GetValue(path + RepNo + ".status", ref strCurrentStatus);
						if (strCurrentStatus == null ||
							strCurrentStatus.Trim().Length == 0)
						{
							response.SetValue(path + RepNo + ".status", (double)ReturnStatus.NO_DATA);
						}
						// response.SetValue(path + RepNo + ".status", (double)ReturnStatus.NO_DATA);
					}
					break;
				case ReturnStatus.SUCCESS: /// Success
					response.SetValue(path + RepNo + ".status", (double)ReturnStatus.SUCCESS);
					break;
				case ReturnStatus.NSSI_ERROR:
					response.SetValue(path + RepNo + ".status", (double)ReturnStatus.NSSI_ERROR);
					break;
				case ReturnStatus.TRANSPORT_ERROR:
					response.SetValue(path + RepNo + ".status", (double)ReturnStatus.TRANSPORT_ERROR);
					break;
				case ReturnStatus.INTERNAL_ERROR:
					/// Certificate Error, Set Sll Status Codes to 4
					if(RepNo == 0)
					{
						response.SetValue(path + "2.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "7.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "14.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "122.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue("GRAO.status", (double)ReturnStatus.INTERNAL_ERROR);
					}
					else /// We Have Report Number so Use it
					{
						response.SetValue(path + RepNo + ".status", (double)ReturnStatus.INTERNAL_ERROR);
					}
					break;
				default:
					response.SetValue(path + "2.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "7.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "14.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "122.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue("GRAO.status", (double)ReturnStatus.INTERNAL_ERROR);
					break;
			}
		}

		private void setOutcome(string strReportNumber, ReturnStatus status_code)
		{
			string path = "report";
			switch(status_code)
			{
				case ReturnStatus.NO_DATA:
					if(strReportNumber != "GRAO")
					{
						response.SetValue(path + "2.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "7.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "14.status", (double)ReturnStatus.NO_DATA);
						response.SetValue(path + "122.status", (double)ReturnStatus.NO_DATA);
						response.SetValue("GRAO.status", (double)ReturnStatus.NO_DATA);
					}
					else
					{
						response.SetValue(strReportNumber + ".status", (double)ReturnStatus.NO_DATA);
					}
					break;
				case ReturnStatus.SUCCESS: /// Success
					response.SetValue(strReportNumber + ".status", (double)ReturnStatus.SUCCESS);
					break;
				case ReturnStatus.NSSI_ERROR:
					response.SetValue(strReportNumber + ".status", (double)ReturnStatus.NSSI_ERROR);
					break;
				case ReturnStatus.TRANSPORT_ERROR:
					response.SetValue(strReportNumber + ".status", (double)ReturnStatus.TRANSPORT_ERROR);
					break;
				case ReturnStatus.INTERNAL_ERROR:
					/// Certificate Error, Set All Status Codes to 4
					if(strReportNumber != "GRAO")
					{
						response.SetValue(path + "2.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "7.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "14.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue(path + "122.status", (double)ReturnStatus.INTERNAL_ERROR);
						response.SetValue("GRAO.status", (double)ReturnStatus.INTERNAL_ERROR);
					}
					else /// We Have Report Number so Use it
					{
						response.SetValue(strReportNumber + ".status", (double)ReturnStatus.INTERNAL_ERROR);
					}
					break;
				default:
					response.SetValue(path + "2.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "7.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "14.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue(path + "122.status", (double)ReturnStatus.INTERNAL_ERROR);
					response.SetValue("GRAO.status", (double)ReturnStatus.INTERNAL_ERROR);
					break;
			}
		}

		#endregion Set Outcome methods

		#region GRAO Helper Functions

		private bool SetResponseValue(string strRootPath, XmlNode objRootNode, string strReportType)
		{
			bool bResult = true;
			try
			{
				foreach (XmlNode objXmlNode in objRootNode.ChildNodes)
				{
					if (objXmlNode.HasChildNodes &&
						objXmlNode.FirstChild.NodeType != XmlNodeType.Text)
					{
						if (!SetResponseValue(string.Format("{0}{1}.", strRootPath, objXmlNode.Name), objXmlNode, strReportType))
						{
							bResult = false;
						}
					}
					else
					{
						response.SetValue(string.Format("{0}{1}", strRootPath, objXmlNode.Name), objXmlNode.InnerText);
					}
				}
			}
			catch (Exception e)
			{
				EventViewer.WriteError("NssiConnect: SetResponseValue " + e.Message);
				setOutcome(strReportType,ReturnStatus.INTERNAL_ERROR);
				bResult = false;
			}

			return bResult;
		}

		private bool SetResponseArray(string strRootPath, XmlNode objRootNode, string strReportType)
		{
			bool bResult = true;
			try
			{
				int nIndex = 0;
				foreach (XmlNode objXmlNode in objRootNode.ChildNodes)
				{
					if (objXmlNode.HasChildNodes &&
						objXmlNode.FirstChild.NodeType != XmlNodeType.Text)
					{
						if (!SetResponseValue(string.Format("{0}{2}.[{1}].", strRootPath, nIndex, objXmlNode.Name), objXmlNode, strReportType))
						{
							bResult = false;
							break;
						}
					}
					else
					{
						response.SetValue(string.Format("{0}{2}.[{1}].", strRootPath, nIndex, objXmlNode.Name), objXmlNode.InnerText);
					}

					nIndex++;
				}
			}
			catch (Exception e)
			{
				EventViewer.WriteError("NssiConnect: SetResponseArray " + e.Message);
				setOutcome(strReportType,ReturnStatus.INTERNAL_ERROR);
				bResult = false;
			}

			return bResult;
		}

		#endregion GRAO Helper Functions

		#endregion Private Methods
	}
}