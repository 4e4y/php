using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Experian.BureauTools.Shared;
using Experian.BureauTools.Shared.UnmanagedWrappers;
using System.Threading;
using System.Data;
using System.Xml;

using System.Configuration;

namespace NSSIConnect
{
	class NSSIConnectClient
	{

		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				if (args.Length != 2)
				{
					throw new Exception("ExternalCalls::NssiConnect invalid arguments");
				}
				NSSIConnectClient client = new NSSIConnectClient(args);
				client.Run();
			}
			catch (Exception ex)
			{
				EventViewer.WriteError("NssiConnect: " + ex.Message);
				// EventViewer.WriteError("NssiConnect: " + ex.ToString());
			}
		}
		private ManagedMetaObject request;
		private ManagedMetaObject response;
		private string requestPath = "";
		private string responsePath = "";
		//Used for acquiring certificate
		private WinCapi d;
		private X509Certificate theCert;
		//The web service proxy
		private Service12 serviceProxy;
		//These hold request values
		short reqType= 0;
		short RepNo = 0;
		string bulstat = "";
		short FromYear = 0;
		short ToYear = 0;
		short FromMonth = 0;
		short ToMonth = 0;
		string EGN = "";
		//This holds the result data
		DataSet dataSet;
		//Constant values for status codes
		private const short NO_DATA = 0;
		private const short SUCCESS = 1;
		private const short NSSI_ERROR = 2;
		private const short TRANSPORT_ERROR = 3;
		private const short INTERNAL_ERROR = 4;

		bool TestFlag = false;

		public NSSIConnectClient(string[] args)
		{
			int i;
			requestPath = args[0];
			responsePath = args[1];
			request = ManagedCallHelper.ReadFile(requestPath);
			try
			{
				response = ManagedMetaObject.Create();
			}
			catch (Exception e)
			{
				e = e;
			}

			if (ConfigurationSettings.AppSettings["testSubscribers"] != null)
			{
				string SID = "";			
				string AppTestSubscribersStr = "";
				request.GetValue("[0].SID", ref SID);
				AppTestSubscribersStr = ConfigurationSettings.AppSettings["testSubscribers"];
				string CurrTestSubscriber = "";
				int TestSubscribersCnt = 0;
				TestSubscribersCnt = AppTestSubscribersStr.Split(',').Length;
				for(i=0; i<TestSubscribersCnt; i++)
				{
					CurrTestSubscriber = AppTestSubscribersStr.Split(',')[i].Trim();
					if(CurrTestSubscriber == SID)
					{
						TestFlag = true;
						break;
					}
				}
			}
		}
        
		public void Run()
		{
			int i;
			// EventViewer.WriteInformation(string.Format("TestFlag - {0}", TestFlag));
			if(!TestFlag)
				processRequest();
			//EventViewer.WriteInformation(string.Format("After: processRequest - {0}", DateTime.Now.ToString("ddMMyyy HHmm")));
			try
			{
				if(!TestFlag)
				{
					ManagedCallHelper.WriteFile(responsePath, response);
				}
				else
				{
					string TestFilesPath = requestPath;

					int DirEndPos = TestFilesPath.LastIndexOf("\\");
					if(DirEndPos >= 0)
						TestFilesPath = TestFilesPath.Remove(DirEndPos, TestFilesPath.Length-DirEndPos);
					DirEndPos = TestFilesPath.LastIndexOf("\\");
					if(DirEndPos >= 0)
						TestFilesPath = TestFilesPath.Remove(DirEndPos, TestFilesPath.Length-DirEndPos);
					DirEndPos = TestFilesPath.LastIndexOf("\\");
					if(DirEndPos >= 0)
						TestFilesPath = TestFilesPath.Remove(DirEndPos, TestFilesPath.Length-DirEndPos);

					TestFilesPath = TestFilesPath + "\\";

					FileStream FSTestReport2 = File.OpenRead(TestFilesPath+"TestReport2.xml");
					FileStream FSTestReport7 = File.OpenRead(TestFilesPath+"TestReport7.xml");
					FileStream FSTestReport122 = File.OpenRead(TestFilesPath+"TestReport122.xml");

					long TestReport2Len = 0;
					long TestReport7Len = 0;
					long TestReport122Len = 0;

					FSTestReport2.Seek(0, SeekOrigin.End);
					FSTestReport7.Seek(0, SeekOrigin.End);
					FSTestReport122.Seek(0, SeekOrigin.End);

					TestReport2Len = FSTestReport2.Position;
					TestReport7Len = FSTestReport7.Position;
					TestReport122Len = FSTestReport122.Position;

					FSTestReport2.Seek(0, SeekOrigin.Begin);
					FSTestReport7.Seek(0, SeekOrigin.Begin);
					FSTestReport122.Seek(0, SeekOrigin.Begin);

					byte ReadB;
					MemoryStream MSTestReport2 = new MemoryStream();
					MemoryStream MSTestReport7 = new MemoryStream();
					MemoryStream MSTestReport122 = new MemoryStream();
					
					while(TestReport2Len > 0)
					{
						ReadB = (byte)FSTestReport2.ReadByte();
						MSTestReport2.WriteByte(ReadB);
						TestReport2Len--;
					}
					while(TestReport7Len > 0)
					{
						ReadB = (byte)FSTestReport7.ReadByte();
						MSTestReport7.WriteByte(ReadB);
						TestReport7Len--;
					}
					while(TestReport122Len > 0)
					{
						ReadB = (byte)FSTestReport122.ReadByte();
						MSTestReport122.WriteByte(ReadB);
						TestReport122Len--;
					}
					string BegStr = "<s>\r\n";
					string EndStr = "</s>\r\n";

					
					MemoryStream MSBegStr = new MemoryStream();
					MemoryStream MSEndStr = new MemoryStream();

					for(i=0; i<BegStr.Length; i++)
						MSBegStr.WriteByte((byte)BegStr[i]);
					for(i=0; i<EndStr.Length; i++)
						MSEndStr.WriteByte((byte)EndStr[i]);

					request.GetValue("[0].requestType", ref reqType);
					if(reqType != 0)
					{
						if(reqType == 1) //report2 and/or report7
						{
							short RepNo1 = 0, RepNo2 = 0;
							bool Rep2Flag = false, Rep7Flag = false;
							request.GetValue("[0].RepNo", ref RepNo1);
							request.GetValue("[1].RepNo", ref RepNo2);
							if(RepNo1 == 2)
								Rep2Flag = true;
							if(RepNo1 == 7)
								Rep7Flag = true;
							if(RepNo2 == 2)
								Rep2Flag = true;
							if(RepNo2 == 7)
								Rep7Flag = true;
							FileStream FSOutFile = File.Create(responsePath);
							FSOutFile.Write(MSBegStr.GetBuffer(), 0, (int)MSBegStr.Length);					
							if(Rep2Flag)
								FSOutFile.Write(MSTestReport2.GetBuffer(), 0, (int)MSTestReport2.Length);
							if(Rep7Flag)
								FSOutFile.Write(MSTestReport7.GetBuffer(), 0, (int)MSTestReport7.Length);
							FSOutFile.Write(MSEndStr.GetBuffer(), 0, (int)MSEndStr.Length);					
						}
						if(reqType == 2) //report122
						{
							RepNo = 0;
							request.GetValue("[0].RepNo", ref RepNo);
							if(RepNo == 122)
							{
								FileStream FSOutFile = File.Create(responsePath);
								FSOutFile.Write(MSBegStr.GetBuffer(), 0, (int)MSBegStr.Length);					
								FSOutFile.Write(MSTestReport122.GetBuffer(), 0, (int)MSTestReport122.Length);
								FSOutFile.Write(MSEndStr.GetBuffer(), 0, (int)MSEndStr.Length);					
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				EventViewer.WriteError("NssiConnect: WriteFile " + ex.Message);
			}
			
			try
			{
				if (d != null)
				{
					d.freeRessources();
				}
			}
			catch(Exception ex)
			{
				EventViewer.WriteError("NssiConnect: Free Ressources " + ex.Message);
			}
		}

		private void processRequest()
		{
			XmlNode resp = new XmlDocument();
			request.GetValue("[0].requestType", ref reqType);
			int success = 0;

			if(reqType != 0)
			{
				//Load certificate only if we need to perform an enquiry
				d = new WinCapi();
				theCert = d.getCertificate();
				if (theCert == null) 
				{
					setOutcome(0,INTERNAL_ERROR);
					return; //no certificate - no deal
				}
				serviceProxy = new Service12(theCert);
			}
			else 
			{
				setOutcome(0,NO_DATA);
				return;
			}

#if NOREQUEST
			setOutcome(reqType, SUCCESS);
			return;;
#endif

			switch (reqType)
			{
				case 1: //Consumer Enquiry
				{
					#region Report 2

                    RepNo = 0;
					request.GetValue("[0].RepNo", ref RepNo);
					request.GetValue("[0].Bulstat", ref bulstat);
					request.GetValue("[0].FromYear", ref FromYear);
					request.GetValue("[0].ToYear", ref ToYear);
					request.GetValue("[0].FromMonth", ref FromMonth);
					request.GetValue("[0].ToMonth", ref ToMonth);
					request.GetValue("[0].EGN", ref EGN);

#if DEBUG
					// ManagedCallHelper.WriteFile(@"D:\Atlas\Debug\request.xml", request);
#endif
					if(RepNo != 0)
					{
						// This is temporary solution for NOI bug with MAX duration period
						// If duration period is more than 10 months then we set period to 10 months
						// DateTime dtTempFrom = new DateTime(FromYear, FromMonth, 1);
						DateTime dtTempTo = new DateTime(ToYear, ToMonth, 1);
						DateTime dtTempFrom = dtTempTo.Subtract(TimeSpan.FromDays(334));

						try
						{

#if MONACO
#if DEMO
							resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
							// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
							resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
							resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif

						}
						catch (Exception ex)
						{
							EventViewer.WriteError("ProcessRequest R2:" + ex.Message);
							setOutcome(RepNo,TRANSPORT_ERROR);
							success = 1;
							if (RepNo == 7) return; //if rep 7 is the first report then only one report was requested so exit
						}

						if (resp.HasChildNodes)
						{
							int nRequestCounts = 0;
							while (resp.HasChildNodes &&
								resp.FirstChild.Name == "NODATA")
							{
								try
								{
									using(StreamWriter objStreamWriter = new StreamWriter(string.Format(@"D:\Atlas\Bin\NSSIErrorRequests_{0}.log", DateTime.Now.ToString("yyyyMMdd")), true))
									{
										objStreamWriter.WriteLine("NSSI NODATA Response Report No;{0};{1};{2};{3}", 
											RepNo, 
											resp.FirstChild.InnerText,
											DateTime.Now.ToString("yyyyMMddHHmmss"),
											EGN);
									}
								}
								catch (Exception)
								{
									EventViewer.WriteError("Error saving unsuccessful request.");
								}

								if (nRequestCounts > 2)
								{
									break;
								}

								//EventViewer.WriteInformation("Report 2: " + nRequestCounts);

								try
								{

#if MONACO
#if DEMO
									resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
									// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
									resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
									resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif

								}
								catch (Exception ex)
								{
									EventViewer.WriteError("ProcessRequest R2N:" + ex.Message);
									setOutcome(RepNo,TRANSPORT_ERROR);
									// success = 1;
									if (RepNo == 7) return; //if rep 7 is the first report then only one report was requested so exit
								}

								nRequestCounts++;
							}

							//EventViewer.WriteInformation("Additional requests: " + nRequestCounts);
						}

						if (success == 0) 
						{
							processResponse(resp,RepNo);
							RepNo = 0;
						}
					}

					#endregion Report 2

					#region Report 7
                    
					RepNo = 0;
					request.GetValue("[1].RepNo", ref RepNo);
					request.GetValue("[1].Bulstat", ref bulstat);
					request.GetValue("[1].FromYear", ref FromYear);
					request.GetValue("[1].ToYear", ref ToYear);
					request.GetValue("[1].FromMonth", ref FromMonth);
					request.GetValue("[1].ToMonth", ref ToMonth);
					request.GetValue("[1].EGN", ref EGN);

					if(RepNo != 0)
					{
						// This is temporary solution for NOI bug with MAX duration period
						// If duration period is more than 10 months then we set period to 10 months
						// DateTime dtTempFrom = new DateTime(FromYear, FromMonth, 1);
						DateTime dtTempTo = new DateTime(ToYear, ToMonth, 1);
						DateTime dtTempFrom = dtTempTo.Subtract(TimeSpan.FromDays(334));

						try
						{
#if MONACO
#if DEMO
							resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
							// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
							resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
							resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
						}
						catch (Exception ex)
						{
							EventViewer.WriteError("ProcessRequest R7:" + ex.Message);
							setOutcome(RepNo,TRANSPORT_ERROR);
							return; //in case of error always exit becasue only two reports are possible
						}

						if (resp.HasChildNodes)
						{
							int nRequestCounts = 0;
							while (resp.HasChildNodes &&
								resp.FirstChild.Name == "NODATA")
							{
								try
								{
									using(StreamWriter objStreamWriter = new StreamWriter(string.Format(@"D:\Atlas\Bin\NSSIErrorRequests_{0}.log", DateTime.Now.ToString("yyyyMMdd")), true))
									{
										objStreamWriter.WriteLine("NSSI NODATA Response Report No;{0};{1};{2};{3}", 
											RepNo, 
											resp.FirstChild.InnerText,
											DateTime.Now.ToString("yyyyMMddHHmmss"),
											EGN);
									}
								}
								catch (Exception)
								{
									EventViewer.WriteError("Error saving unsuccessful request.");
								}

								if (nRequestCounts > 2)
								{
									break;
								}

								//EventViewer.WriteInformation("Report 7: " + nRequestCounts);

								try
								{

#if MONACO
#if DEMO
									resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
									// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
									resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
									resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
								}
								catch (Exception ex)
								{
									EventViewer.WriteError("ProcessRequest R7N:" + ex.Message);
									setOutcome(RepNo,TRANSPORT_ERROR);
									return; //in case of error always exit becasue only two reports are possible
								}

								nRequestCounts++;
							}

							//EventViewer.WriteInformation("Additional requests: " + nRequestCounts);
						}

						processResponse(resp,RepNo);
					}

					#endregion Report 7

					#region Report 14
                    
					RepNo = 0;
					request.GetValue("[2].RepNo", ref RepNo);
					request.GetValue("[2].Bulstat", ref bulstat);
					request.GetValue("[2].FromYear", ref FromYear);
					request.GetValue("[2].ToYear", ref ToYear);
					request.GetValue("[2].FromMonth", ref FromMonth);
					request.GetValue("[2].ToMonth", ref ToMonth);
					request.GetValue("[2].EGN", ref EGN);

					if(RepNo != 0)
					{
						// This is temporary solution for NOI bug with MAX duration period
						// If duration period is more than 10 months then we set period to 10 months
						// DateTime dtTempFrom = new DateTime(FromYear, FromMonth, 1);
						DateTime dtTempTo = new DateTime(ToYear, ToMonth, 1);
						DateTime dtTempFrom = dtTempTo.Subtract(TimeSpan.FromDays(334));

						try
						{
#if MONACO
#if DEMO
							resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
							// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
							resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
							resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
						}
						catch (Exception ex)
						{
							EventViewer.WriteError("ProcessRequest R14:" + ex.Message);
							setOutcome(RepNo,TRANSPORT_ERROR);
							return; //in case of error always exit becasue only two reports are possible
						}

						if (resp.HasChildNodes)
						{
							int nRequestCounts = 0;
							while (resp.HasChildNodes &&
								resp.FirstChild.Name == "NODATA")
							{
								try
								{
									using(StreamWriter objStreamWriter = new StreamWriter(string.Format(@"D:\Atlas\Bin\NSSIErrorRequests_{0}.log", DateTime.Now.ToString("yyyyMMdd")), true))
									{
										objStreamWriter.WriteLine("NSSI NODATA Response Report No;{0};{1};{2};{3}", 
											RepNo, 
											resp.FirstChild.InnerText,
											DateTime.Now.ToString("yyyyMMddHHmmss"),
											EGN);
									}
								}
								catch (Exception)
								{
									EventViewer.WriteError("Error saving unsuccessful request.");
								}

								if (nRequestCounts > 2)
								{
									break;
								}

								//EventViewer.WriteInformation("Report 7: " + nRequestCounts);

								try
								{

#if MONACO
#if DEMO
									resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
									// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
									resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
									resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
								}
								catch (Exception ex)
								{
									EventViewer.WriteError("ProcessRequest R7N:" + ex.Message);
									setOutcome(RepNo,TRANSPORT_ERROR);
									return; //in case of error always exit becasue only two reports are possible
								}

								nRequestCounts++;
							}

							//EventViewer.WriteInformation("Additional requests: " + nRequestCounts);
						}

						processResponse(resp,RepNo);
					}

					#endregion Report 14

					break;
				}
				case 2: //Business Enquiry
				{
					RepNo = 0;
					request.GetValue("[0].RepNo", ref RepNo);
					request.GetValue("[0].Bulstat", ref bulstat);
					request.GetValue("[0].FromYear", ref FromYear);
					request.GetValue("[0].ToYear", ref ToYear);
					request.GetValue("[0].FromMonth", ref FromMonth);
					request.GetValue("[0].ToMonth", ref ToMonth);
					request.GetValue("[0].EGN", ref EGN);
					if(RepNo != 0)
					{

						// This is temporary solution for NOI bug with MAX duration period
						// If duration period is more than 10 months then we set period to 10 months
						// DateTime dtTempFrom = new DateTime(FromYear, FromMonth, 1);
						DateTime dtTempTo = new DateTime(ToYear, ToMonth, 1);
						DateTime dtTempFrom = dtTempTo.Subtract(TimeSpan.FromDays(334));

						try
						{
#if MONACO
#if DEMO
							resp = serviceProxy.GetData("exscomonaco2007", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#else
							// resp = serviceProxy.GetData("exscomonaco", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
							resp = serviceProxy.GetData("Monaco2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
#endif

#if BULGARIA
							resp = serviceProxy.GetData("ExScoSofia2008", RepNo, bulstat, dtTempFrom.Year, dtTempTo.Year, dtTempFrom.Month, dtTempTo.Month, EGN);
#endif
						}
						catch(Exception ex)
						{
							EventViewer.WriteError("ProcessRequest R122: " + ex.Message);
							setOutcome(RepNo,TRANSPORT_ERROR);
							return;//always exit because business enquiry has only one report
						}
						processResponse(resp,RepNo);
					}
					break;
				}
				default:
				{
					return;
				}
			}
			
		}

		private void processResponse(XmlNode node, short repType)
		{
#if DEBUG
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(node.OuterXml);
			doc.Save(string.Format(@"d:\Atlas\Debug\debug_rep{0}_{1}.xml", repType, DateTime.Now.Ticks));
#endif
						
			if(!node.HasChildNodes)
			{
				setOutcome(repType,NO_DATA);
				return;
			} 
			else if (node.FirstChild.Name == "NODATA")
			{
				EventViewer.WriteError("NssiConnect: Nssi error "  + node.FirstChild.InnerText);
				setOutcome(repType,NSSI_ERROR);
				return;
			}
			else 
			{
				setOutcome(repType,SUCCESS);//set success here, if anything goes wrong status will be overriden
			}
			try
			{
				dataSet = new DataSet();
				XmlNodeReader xReader = new XmlNodeReader(node);
				dataSet.ReadXml(xReader, XmlReadMode.InferSchema);
				string path = "report" + repType + ".";
				int index = 0;
				string tbl = "";
				string rusoPath = "Ruso";
				bool rusoChanged = false;
				foreach (DataTable table in dataSet.Tables)
				{
					tbl = table.TableName;
					if(tbl == "PersonalInfo")
					{
						string currRuso = "";
						string currBulstat = "";
						int RusoIndex = 0;
						int BulstatIndex = 0;
						//first get the rows ordered by ruso
						DataRow[] rusoArray = table.Select("","Ruso,Bulstat ASC");
						if(rusoArray.Length > 0)
						{
							currRuso = (string) rusoArray[0]["Ruso"];
							currBulstat = (string) rusoArray[0]["Bulstat"];
							response.SetValue(path + rusoPath +".[" + RusoIndex + "]." + "RusoNbr",currRuso);
							insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "]." + "Bulstat" + ".[" + BulstatIndex + "].", currBulstat, currRuso);
						}
						//for each row check if underneath 
						for(int l = 0; l < rusoArray.Length; l++)
						{
							DataRow currRow = rusoArray[l];
							//next section
							if((string) currRow["Ruso"] != currRuso)
							{
								currRuso = (string) currRow["Ruso"];
								RusoIndex++;
								index = 0;
								rusoChanged = true;
								BulstatIndex = 0;
								response.SetValue(path + rusoPath +".[" + RusoIndex + "]." + "RusoNbr",currRuso);
								insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "].", currBulstat, currRuso);
							}
							if((string) currRow["Bulstat"] != currBulstat)
							{
								currBulstat = (string) currRow["Bulstat"];
								if(!rusoChanged) {BulstatIndex++;}
								insertBulstatInfo(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "].", currBulstat, currRuso);
								index = 0;
								rusoChanged = false;
							}
							for (int k = 0; k < currRow.ItemArray.Length; k++)
							{
								//set path and value
								DataColumn currCol = (DataColumn) table.Columns[k];
								if(currCol.ColumnName != "Ruso" && currCol.ColumnName != "Bulstat")
								{
									response.SetValue(path + rusoPath +".[" + RusoIndex + "].Bulstat.[" + BulstatIndex + "]." + tbl + ".[" + index +"]."+ currCol.ColumnName,(string) currRow[currCol.ColumnName]);
								}
							}
							index++;
						}
					}
					else if (tbl != "BulstatInfo")	
					{
						for (int i = 0; i < table.Rows.Count; i++)
						{
							//set path to row
							index = i;
							DataRow currRow = table.Rows[i];
							for (int k = 0; k < currRow.ItemArray.Length; k++)
							{
								
								//set path and value
								DataColumn currCol = (DataColumn) table.Columns[k];
								if(currCol.ColumnName == "EGN")
								{
									//remove last digit nssi puts on EGN
									response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,((string) currRow[currCol.ColumnName]).Substring(0,10));
								}
								else
								{
									if (currRow[currCol.ColumnName] != null &&
										currRow[currCol.ColumnName] != DBNull.Value)
									{
										response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,(currRow[currCol.ColumnName] as string));
									}
									// response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,(string) currRow[currCol.ColumnName]);
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				try
				{
					XmlDocument docEx = new XmlDocument();
					docEx.LoadXml(node.OuterXml);
					docEx.Save(string.Format(@"d:\Atlas\Debug\debug_rep_NSSI{0}_{1}.xml", repType, DateTime.Now.ToString("yyyyMMdd_HHmmss")));
				}
				catch (Exception)	{}

				EventViewer.WriteError("NssiConnect: Process Response "  + ex.Message);
				setOutcome(repType,INTERNAL_ERROR);
			}
		}

		private void insertBulstatInfo(string thePath, string bulstat, string ruso)
		{
			DataTable bulstatTbl = dataSet.Tables["BulstatInfo"];
			DataRow[] bulstatArray = bulstatTbl.Select("TRIM(Bulstat) =" + bulstat.Trim()  + " and TRIM(Ruso) =" + ruso.Trim());
			if(bulstatArray.Length > 0)
			{
				DataRow currRow = bulstatArray[0];
				for (int k = 0; k < currRow.ItemArray.Length; k++)
				{
					//set path and value
					DataColumn currCol = (DataColumn) bulstatTbl.Columns[k];
					if(currCol.ColumnName != "Ruso")
					{
						if (currRow[currCol.ColumnName] != null &&
							currRow[currCol.ColumnName] != DBNull.Value)
						{
							// response.SetValue(path + tbl + ".["+index+"]." + currCol.ColumnName,(currRow[currCol.ColumnName].ToString()));
							response.SetValue(thePath + bulstatTbl.TableName + "."+ currCol.ColumnName,currRow[currCol.ColumnName].ToString());
						}

						// response.SetValue(thePath + bulstatTbl.TableName + "."+ currCol.ColumnName,(string) currRow[currCol.ColumnName]);
						// response.SetValue(thePath + bulstatTbl.TableName + "."+ currCol.ColumnName,(string) currRow[currCol.ColumnName]);
					}
				}
			}
			else //bulstat number not found in bulstat info try with egninfo
			{
				DataTable egnInfoTbl = dataSet.Tables["EgnInfo"];
				DataRow[] egnArray = egnInfoTbl.Select("EGN LIKE '" + bulstat.Trim() + "*'");
				if(egnArray.Length > 0)
				{
					response.SetValue(thePath + "BulstatInfo.Ruso",ruso);
					DataRow currRow = egnArray[0];
					response.SetValue(thePath + "BulstatInfo.Bulstat",((string) currRow["EGN"]).Substring(0,10));
					response.SetValue(thePath + "BulstatInfo.Name",(string) currRow["familyname"]);
					response.SetValue(thePath + "BulstatInfo.address",(string) currRow["Address"]);
				}
				else // just in case put something there
				{
					response.SetValue(thePath + "BulstatInfo.Ruso",ruso);
					response.SetValue(thePath + "BulstatInfo.Bulstat","");
					response.SetValue(thePath + "BulstatInfo.Name","");
					response.SetValue(thePath + "BulstatInfo.address","");
				}
			}
		}

		private void setOutcome(short RepNo, short status_code)
		{
			string path = "report";
			switch(status_code)
			{
				case NO_DATA:
					if(RepNo == 0)
					{
						response.SetValue(path + "2.status", NO_DATA.ToString());
						response.SetValue(path + "7.status", NO_DATA.ToString());
						response.SetValue(path + "122.status", NO_DATA.ToString());
					}
					else
					{
						response.SetValue(path + RepNo + ".status", NO_DATA.ToString());
					}
					break;
				case SUCCESS: //success
					response.SetValue(path + RepNo + ".status", SUCCESS.ToString());
					break;
				case NSSI_ERROR:
					response.SetValue(path + RepNo + ".status", NSSI_ERROR.ToString());
					break;
				case TRANSPORT_ERROR:
					response.SetValue(path + RepNo + ".status", TRANSPORT_ERROR.ToString());
					break;
				case INTERNAL_ERROR:
					if(RepNo == 0) //certificate error, set all status codes to 4
					{
						response.SetValue(path + "2.status", INTERNAL_ERROR.ToString());
						response.SetValue(path + "7.status", INTERNAL_ERROR.ToString());
						response.SetValue(path + "122.status", INTERNAL_ERROR.ToString());
					}
					else //we have report number so use it
					{
						response.SetValue(path + RepNo + ".status", INTERNAL_ERROR.ToString());
					}
					break;
				default:
					response.SetValue(path + "2.status", INTERNAL_ERROR.ToString());
					response.SetValue(path + "7.status", INTERNAL_ERROR.ToString());
					response.SetValue(path + "122.status", INTERNAL_ERROR.ToString());
					break;
			}
		}

	}
}