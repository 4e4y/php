using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ComponentModel;
using System.Diagnostics;

using Experian.BureauTools.Shared;
using Experian.BureauTools.Shared.UnmanagedWrappers;

namespace NSSIConnect
{
	// public class WinCapi
	public sealed class WinCapi
    {
		WinCapi() 
		{
			byte[] pbData = { 0x30, 0x30, 0x30, 0x30, 0x00 };
			byte[] container = new byte[1000];
 
			/// --------------------------------------------------------------------
			/// DPD 2007/10/24 - make LogonUser to be able to get certificate under Windows 2003 server
			/// Get registry settings to make or not LogonUser action
			int NSSI_LogonUser = 0;
			
			/// If registry key NSSI_LogonUser is not found, keep the old way to capture cerfiticate for NSSI
			/// now NSSI_LogonUser is optional, and default value will be used (0 - do not make Login for specified user)
			ManagedConfiguration.FindValue("NSSI_LogonUser", ref NSSI_LogonUser, 0);
			
			makeLogonUser = (NSSI_LogonUser == 1)? true:false;
			
			try
			{
				if( makeLogonUser )
				{
					ManagedConfiguration.MustFindValue("CertUserName", ref certUserName);
					ManagedCrypto.Decrypt(certUserName.ToString(), ref certUserName);
					ManagedConfiguration.MustFindValue("CertUserPass", ref certUserPass);
					ManagedCrypto.Decrypt(certUserPass.ToString(), ref certUserPass);
                
					bool loggedOn = LogonUser(certUserName, System.Environment.MachineName, certUserPass,
						LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out hToken);

					if (loggedOn)
					{
						if( hToken != IntPtr.Zero)
						{
							if (DuplicateToken(hToken, 2, out hTokenDuplicate))
							{
								WindowsIdentity windowsIdentity = new WindowsIdentity(hTokenDuplicate);
								impersonationContext = windowsIdentity.Impersonate();
							}
						}
					}
					else
					{
						showWin32Error("NssiConnect: Logon with specified user failed ", Marshal.GetLastWin32Error());
						// continue and try CryptAcquireContext within security context of the current user 
					}
				}
			}
			catch (Exception ex)
			{
				showWin32Error("NssiConnect: make Logon " + ex.Message, Marshal.GetLastWin32Error());
			}
#if IIIDC
			EventViewer.WriteInformation("1");
#endif 
			//-------------------------------------------------------------------
			// Get a handle to a PROV_RSA_FULL provider.
			if (CryptAcquireContext(ref hCryptProv,
				// Darina's container Siemens "595f31d2-63e1-48f6-a52b-a3783f82ba2d",
				//Darina's container Utimaco "SC2341171-1",//        
				//"3cf123d8-9b27-44b3-8333-838e5d1f00bb",//Deian's container Siemens 
				// "SC2341171-1",//Darina's container Utimaco 
				Container,
				// "Siemens Card API CSP",
				// "Utimaco Universal Smartcard CSP",
				Provider,
				PROV_RSA_FULL,
				CRYPT_SILENT))
			{
#if IIIDC
				EventViewer.WriteInformation("2");
#endif 
				//-------------------------------------------------------------------
				//Set pin for the card
				if (CryptSetProvParam(hCryptProv,
					PP_KEYEXCHANGE_PIN,
					pbData,
					0))
				{					
#if IIIDC
					EventViewer.WriteInformation("3");
#endif 
					//-------------------------------------------------------------------
					//Get Container name
					//					cbData = 1000;
					//					if (CryptGetProvParam(
					//					    hCryptProv,
					//					    2,
					//					    container,
					//					    ref cbData,
					//					    0))
					//					{
					//					    ASCIIEncoding ascii = new ASCIIEncoding();
					//					    Console.WriteLine("CryptGetProvParam succeeded.\n");
					//					    char[] chars = ascii.GetChars(container);
					//					    foreach (Char c in chars)
					//					    {
					//					        Console.Write("[{0}]", c);
					//					    }
					//					}
#if IIIDC
					EventViewer.WriteInformation("4");
#endif 
					hSysStore = WinCapi.CertOpenSystemStore(hCryptProv, MY);
					//hSysStore = WinCapi.CertOpenStoreStringPara(15,
					//											0,
					//											IntPtr.Zero,
					//											hCryptProv.ToInt32(),
					//											"MY");


					string certSerialNumber = string.Empty;											
					
					if (hSysStore != IntPtr.Zero)
					{
#if IIIDC
						EventViewer.WriteInformation("5");

						CryptSetProvParam(hCryptProv,
							PP_KEYEXCHANGE_PIN,
							pbData,
							0);
#endif 
						hCertCntxt = WinCapi.CertFindCertificateInStore(
							hSysStore,
							MY_ENCODING_TYPE,
							0,
							// CERT_FIND_SUBJECT_STR,
							CERT_FIND_SUBJECT_STR,
							CertSubject,
							hCertCntxt);
#if IIIDC
						EventViewer.WriteInformation("6");
#endif 

#if IIIDC
						EventViewer.WriteInformation(Container);
						EventViewer.WriteInformation(Provider);
						EventViewer.WriteInformation(CertSubject);
#endif

						if (hCertCntxt != IntPtr.Zero)
						{
#if IIIDC
							EventViewer.WriteInformation("7");
#endif 
#if IIIDC
							return new X509Certificate(hCertCntxt);
#endif
							X509Certificate c = new X509Certificate(hCertCntxt);
							DateTime dt = DateTime.Parse(c.GetExpirationDateString());

							StringBuilder sb = new StringBuilder();
							byte[] certSerialNumberBytes = c.GetSerialNumber();
							certSerialNumber = c.GetSerialNumberString();
							for (int i = 0; i < certSerialNumberBytes.Length; i++)
							{
								sb.Append(certSerialNumberBytes);
							}
							
#if DEBUG
							EventViewer.WriteInformation(certSerialNumber);
#endif
							
							while (certSerialNumber.CompareTo(SerialNumber) != 0)
							{
								hCertCntxt = WinCapi.CertFindCertificateInStore(
									hSysStore,
									MY_ENCODING_TYPE,
									0,
									// CERT_FIND_SUBJECT_STR,
									CERT_FIND_SUBJECT_STR,
									CertSubject,
									hCertCntxt);
								

								c = new X509Certificate(hCertCntxt);
								certSerialNumber = c.GetSerialNumberString();
#if DEBUG
								EventViewer.WriteInformation(certSerialNumber);
#endif
							}

							X509Certificate c1 = new X509Certificate(hCertCntxt);
#if DEBUG
							EventViewer.WriteInformation(c1.GetExpirationDateString());
#endif

							// return new X509Certificate(hCertCntxt);
							// return c;
							Nested.certificate = c;

						}
						else
						{
							EventViewer.WriteError("NssiConnect: Certificate not acquired:" + Marshal.GetLastWin32Error());
							EventViewer.WriteError("NssiConnect: Certificate not acquired:" + Marshal.GetExceptionCode());
							EventViewer.WriteError("NssiConnect: Certificate not acquired:" + Marshal.GetHRForLastWin32Error());
							// return null;
							return;
						}
					}
				}
				else
				{
					EventViewer.WriteError("NssiConnect: Crypt Set Pass failed." + Marshal.GetLastWin32Error());
					// return null;
					return;
				}
			}
			else
			{
				EventViewer.WriteError("NssiConnect: A general error occured while acquiring context." + Marshal.GetLastWin32Error());
				// return null;
			}
			// return null;
			return;
		}

		
		public static WinCapi Instance
		{
			get
			{
				return Nested.instance;
			}
		}

		public static X509Certificate Certificate
		{
			get
			{
				return Nested.certificate;
			}
		}

		class Nested
		{
			static Nested() {}

			internal static readonly WinCapi instance = new WinCapi();
			internal static X509Certificate certificate;
		}

		#region Constants

        const string MY   = "MY";
		const uint PKCS_7_ASN_ENCODING    = 0x00010000;
		const uint X509_ASN_ENCODING       = 0x00000001;
		const uint CERT_FIND_SUBJECT_STR   = 0x00080007;
		const uint CERT_FIND_ANY = 0x00080000;
        const uint CRYPT_SILENT = 0x00000040;
		const uint CRYPT_NEWKEYSET = 0x00000008;
		const uint CRYPT_MACHINE_KEYSET = 0x00000020;
        const uint PP_KEYEXCHANGE_PIN = 32;
		const int CERT_SYSTEM_STORE_CURRENT_USER = 0x00080001;
        const uint MY_ENCODING_TYPE  = PKCS_7_ASN_ENCODING | X509_ASN_ENCODING ;
        const uint PROV_RSA_FULL = 0x00000001;

		private string CertSubject
		{
			get
			{
#if MONACO
#if DEMO
				return "Darina Nikolova Oresharova";
#else
				return "Deian Alexandrov Doumbov";
#endif
#endif

#if BULGARIA
				return "DEIAN ALEXANDROV DOUMBOV";
#endif

#if NOTH
				return "Deian Alexandrov Doumbov";
#endif
				return string.Empty;
			}
		}

		private string Container
		{
			get 
			{
#if MONACO
#if DEMO
				return "595f31d2-63e1-48f6-a52b-a3783f82ba2d";
#else
				return "FC:BD:C0:11:6A:15:70:BF:CF:F2:C7:40:D5:4D:D0:17:41:C4:A5:6E";
#endif
#endif
#if BULGARIA
				// return "B758EA26DBF997E892ACA5A4704595828A29AD71";
				// return "7BFF570827043018";
				// return "3B F2 18 00 02 C1 0A 31 FE 58 C8 08 74";
				// return "FC:BD:C0:11:6A:15:70:BF:CF:F2:C7:40:D5:4D:D0:17:41:C4:A5:6E";
				// return "3B F8 13 00 00 81 31 FE 45 4A 43 4F 50 76 32 34 31 B7"
#if IIIDC
				return "66:13:30:FD:DC:AB:98:A5:8E:50:B2:45:71:06:EE:3D:2E:90:54:DB";
				// return "7b 5e f4 be 8f 9f 33 c8 05 6e 10 51 af a2 26 df 42 41 b4 03";
				// return "c2 1f 04 6a e3 9f 3a 6f 6d 02 07 67 d0 b7 a9 c6 2a 3b 52 b9";
				// return "c217046ae39f3a6f6d020767d0b7a9c62a3b52b9";
#endif
				return "35:DE:3D:F5:47:E3:F4:6D:FF:06:2C:0C:7C:F5:57:1E:92:ED:BA:66"; //////// WORKING
#endif

#if NOTH
				string strMachineName = System.Environment.MachineName;
				if (strMachineName.Trim().EndsWith("DBC01"))
				{
					return "51:BD:64:8B:63:AA:2C:D2:E7:74:D1:FD:E0:18:75:E9:30:AB:33:5C";
				}
				if (strMachineName.Trim().EndsWith("DBC02"))
				{
					return "A0:84:AD:17:A4:E6:96:AB:68:FB:0B:7E:98:57:F3:8A:03:1F:FD:BF";
				}
#endif
				return string.Empty;
			}
		}

		private string Provider
		{
			get
			{
#if MONACO
				return "Siemens Card API CSP";
#endif

#if BULGARIA
				// return "Advanced Setec SetCSP";
#if IIIDC
				// return "Microsoft Base Smart Card Crypto Provider";
				return "cv act sc/interface CSP";
#endif
				return "Siemens Card API CSP";
#endif

#if NOTH
				return "Charismathics Smart Security Interface CSP";
#endif
        
				return string.Empty;
			}
		}


		private string SerialNumber
		{
			get
			{
#if BULGARIA
				return "54029900";
#endif

#if IIIDC
				return "59029900";
#endif
			}
		}
		/*
#if MONACO
#if DEMO
		const string lpszCertSubject = "Darina Nikolova Oresharova";
		const string strContainer = "595f31d2-63e1-48f6-a52b-a3783f82ba2d";
#else
		const string lpszCertSubject = "Deian Alexandrov Doumbov";
		const string strContainer = "FC:BD:C0:11:6A:15:70:BF:CF:F2:C7:40:D5:4D:D0:17:41:C4:A5:6E";
#endif
		const string strProvider = "Siemens Card API CSP";
#endif

#if BULGARIA
		const string lpszCertSubject = "Deian Alexandrov Doumbov";
		const string strContainer = "B758EA26DBF997E892ACA5A4704595828A29AD71";
		const string strProvider = "Advanced Setec SetCSP";
#endif

#if NOTH
		string strMachineName = System.Environment.MachineName;
		if (strMachineName.Trim().EndsWith("DBC01"))
		{
			return "Ukdbc012009";
		}
			if (strMachineName.Trim().EndsWith("DBC02"))
		{
			return "Ukdbc022009";
		}

#if NODE1
		const string lpszCertSubject = "Deian Alexandrov Doumbov";
		const string strContainer = "51:BD:64:8B:63:AA:2C:D2:E7:74:D1:FD:E0:18:75:E9:30:AB:33:5C";
		const string strProvider = "Charismathics Smart Security Interface CSP";
#endif
#if NODE2
		const string lpszCertSubject = "Deian Alexandrov Doumbov";
		const string strContainer = "A0:84:AD:17:A4:A6:96:AB:68:FB:0B:7E:98:57:F3:8A:03:1F:FD:BF";
		const string strProvider = "Charismathics Smart Security Interface CSP";
#endif
#endif
*/
        
		#endregion Constants

        IntPtr hCryptProv = IntPtr.Zero;
        IntPtr hSysStore = IntPtr.Zero;
        public static IntPtr hCertCntxt = IntPtr.Zero;

		// for LogonUser needs
		bool makeLogonUser = false;
		//bool useProxy = false;
        const int LOGON32_LOGON_INTERACTIVE   = 2;
		const int LOGON32_PROVIDER_DEFAULT    = 0;
		string certUserName = "";
		string certUserPass = "";
		IntPtr hToken;
		IntPtr hTokenDuplicate;
        WindowsImpersonationContext impersonationContext;

		public void freeRessources()
        {
            if (hSysStore != IntPtr.Zero)
            {
                CertCloseStore(hSysStore, 0);
            }
            if (hCryptProv != IntPtr.Zero)
            {
                CryptReleaseContext(hCryptProv, 0);
            }
			if (hCertCntxt != IntPtr.Zero)
			{
				CertFreeCertificateContext(hCertCntxt);
			}
			if (makeLogonUser)
			{
				if (hToken != IntPtr.Zero)
				{
					CloseHandle(hToken);
				}
				if(hTokenDuplicate != IntPtr.Zero)
				{
					CloseHandle(hTokenDuplicate);
					impersonationContext.Undo();
				}
			}
        }

		// DPD 2007/10/24 Caputre error with better description (message + code)
		public static void showWin32Error(string myMsg, int errorcode)
		{
			Win32Exception myEx=new Win32Exception(errorcode);
			string evMsg = "";

			evMsg += "\nMy Message:\t " + myMsg;
			evMsg += "\nError code:\t " + myEx.ErrorCode;
			evMsg += "\nHRESULT:\t " + String.Format("0x{0:X8}",errorcode);
			evMsg += "\nError message:\t " + myEx.Message;
			evMsg += "\n" + myEx.Source;
			evMsg += "\n" + myEx.HelpLink;
			evMsg += "\n";
			EventViewer.WriteError(evMsg);
		}

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool CryptAcquireContext(ref IntPtr hProv, string pszContainer,
        string pszProvider, uint dwProvType, uint dwFlags);

        [DllImport("advapi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CryptReleaseContext(IntPtr hProv, uint dwFlags);

        [DllImport("advapi32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CryptSetProvParam(IntPtr hProv, uint dwParam, [In] byte[] pbData, uint dwFlags);

        [DllImport("advapi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool CryptGetProvParam(IntPtr hProv, uint dwParam, [In, Out] byte[] pbData,
           ref uint dwDataLen, uint dwFlags);

        [DllImport("crypt32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern IntPtr CertOpenSystemStore(IntPtr hCryptProv, string storename);

        [DllImport("crypt32.dll", SetLastError = true)]
        static extern bool CertCloseStore(
            IntPtr hCertStore,
            uint dwFlags);
        
        [DllImport("crypt32.dll", SetLastError = true)]
        static extern IntPtr CertFindCertificateInStore(
            IntPtr hCertStore,
            uint dwCertEncodingType,
            uint dwFindFlags,
            uint dwFindType,
            [In, MarshalAs(UnmanagedType.LPWStr)]String pszFindString,
            IntPtr pPrevCertCntxt);

        [DllImport("crypt32.dll", SetLastError = true)]
        static extern bool CertFreeCertificateContext(
            IntPtr hCertStore);
		
		[DllImport("CRYPT32.DLL", EntryPoint="CertOpenStore", CharSet=CharSet.Auto, SetLastError=true)]
		public static extern IntPtr CertOpenStoreStringPara( int storeProvider, int encodingType,
			IntPtr hcryptProv, int flags, String pvPara);

		[DllImport("advapi32.dll", SetLastError=true)]
		public static extern bool LogonUser(
			string lpszUsername,
			string lpszDomain,
			string lpszPassword,
			int dwLogonType,
			int dwLogonProvider,
			out IntPtr phToken
			);

		[DllImport("advapi32.dll", SetLastError=true)]
		public extern static bool DuplicateToken(
			IntPtr ExistingTokenHandle, 
			int SECURITY_IMPERSONATION_LEVEL, 
			out IntPtr DuplicateTokenHandle
			);

		[DllImport("kernel32.dll", SetLastError=true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		static extern bool CloseHandle(IntPtr hObject);
    }
}
